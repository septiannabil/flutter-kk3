package com.example.shabrina_08

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
